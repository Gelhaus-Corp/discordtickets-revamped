import{l as p,y as t}from"./w0yj2jlX.js";import{B as c}from"./D6OMl6Um.js";function m(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{m as s};
