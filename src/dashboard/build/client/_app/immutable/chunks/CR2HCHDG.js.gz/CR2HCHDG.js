import{l as p,y as t}from"./CWXCXDbJ.js";import{B as c}from"./DU73alKZ.js";function m(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{m as s};
