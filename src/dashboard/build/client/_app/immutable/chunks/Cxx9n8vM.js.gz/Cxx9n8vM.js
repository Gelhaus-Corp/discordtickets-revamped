import{H as o,R as e}from"./CYgJF_JY.js";import"./B17Q6ahh.js";function a(r,t){throw new o(r,t)}function c(r,t){throw new e(r,t.toString())}export{a as e,c as r};
