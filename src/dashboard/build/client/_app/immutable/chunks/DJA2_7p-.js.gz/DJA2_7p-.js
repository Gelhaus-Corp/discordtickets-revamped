import{U as t}from"./_fu6EM7d.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
