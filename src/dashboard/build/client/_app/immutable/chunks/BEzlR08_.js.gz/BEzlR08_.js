import{U as t}from"./w0yj2jlX.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
