import{U as t}from"./CWXCXDbJ.js";const o=t({questions:[]}),a=t({tags:[]});export{o as q,a as t};
