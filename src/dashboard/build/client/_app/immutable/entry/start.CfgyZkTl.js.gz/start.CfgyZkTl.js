import{a as r}from"../chunks/D4qYK9Iq.js";import{x as t}from"../chunks/CaUQ-Vxm.js";export{t as load_css,r as start};
