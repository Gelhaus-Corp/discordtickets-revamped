import{a as r}from"../chunks/L_7WN5SN.js";import{x as t}from"../chunks/Bt5PpDoa.js";export{t as load_css,r as start};
