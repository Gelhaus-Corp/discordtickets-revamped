import{a as t}from"../chunks/D7lDQOeK.js";export{t as start};
