import{a as r}from"../chunks/Bv4gk3jo.js";import{x as t}from"../chunks/k1vYC2Pw.js";export{t as load_css,r as start};
