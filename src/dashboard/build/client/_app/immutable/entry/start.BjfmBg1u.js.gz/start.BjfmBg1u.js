import{a as r}from"../chunks/hFXt_2hJ.js";import{x as t}from"../chunks/BMZ6xVa9.js";export{t as load_css,r as start};
