import{a as r}from"../chunks/BNayoZz7.js";import{x as t}from"../chunks/DTs6c9Q0.js";export{t as load_css,r as start};
