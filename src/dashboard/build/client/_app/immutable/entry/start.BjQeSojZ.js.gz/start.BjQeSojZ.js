import{a as r}from"../chunks/C1PfqNCt.js";import{x as t}from"../chunks/BR6RR1uv.js";export{t as load_css,r as start};
