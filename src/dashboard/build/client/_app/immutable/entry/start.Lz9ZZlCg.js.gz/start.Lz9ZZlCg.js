import{a as r}from"../chunks/2uW-fUb1.js";import{x as t}from"../chunks/B0cRaLJL.js";export{t as load_css,r as start};
