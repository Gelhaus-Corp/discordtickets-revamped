import{a as r}from"../chunks/Drnsocvb.js";import{x as t}from"../chunks/DUFA_US_.js";export{t as load_css,r as start};
