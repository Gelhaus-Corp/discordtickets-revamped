import{a as r}from"../chunks/B4jARqj1.js";import{x as t}from"../chunks/DwXo21th.js";export{t as load_css,r as start};
