import{a as r}from"../chunks/q3P-UJff.js";import{x as t}from"../chunks/CmfPTRZR.js";export{t as load_css,r as start};
