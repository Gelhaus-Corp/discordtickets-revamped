import{a as r}from"../chunks/Bhd2hp12.js";import{x as t}from"../chunks/BD2RfKcQ.js";export{t as load_css,r as start};
